import React from 'react';

class ChildThree extends React.Component {
   render() {
      return (
         <div>
            <h3 style={{backgroundColor:this.props.childthreeprops}}>HI i am Third child</h3>
         </div>
      );
   }
}
export default ChildThree;
