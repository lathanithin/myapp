import React from 'react';
import ChildOne from './ChildOne.js';
import ChildTwo from './ChildTwo.js';
import ChildThree from './ChildThree.js';
class App extends React.Component {
   constructor(props) {
      super(props);
      this.state = {
        colorCode:{
          childonecolor : "#fff",
          childtwocolor : "#fff",
          childthreecolor : "#fff"
        },
        hi: 'Nithin',
        value: 'white',
        value1: 'white'
      };
      this.change = this.change.bind(this);
   }
   change(event){
        this.setState({
            value: event.target.value
      });
    }
    shouldComponentUpdate(nextProps, nextState){
      // console.log(this.state.value);
      // console.log(nextState.value);
      // console.log(this.state.value);
      // console.log("red");
      if(this.state.value===nextState.value && this.state.value==="red"){
          console.log("Can not update same red color");
          // if(this.state.value1==="red" && this.state.value1===nextState.value1){
          //   console.log("color will change to green");
          //   setTimeout(function() {
          //      this.setState({
          //           value1: "green"
          //         });
          //       }.bind(this),1000) ;
          //       return true;
          // }
          // else{
          //   ()=> {
          //      this.setState({
          //           value1: ''
          //         });
          //       }
          // }
          return false;
      }
        return true;
    }
   render() {
      return (
         <div>
            <ChildOne  valueone={this.state.value} />
            <ChildTwo valuetwo={this.state.value1}/>
            <ChildThree childthreeprops={this.state.colorCode.childthreecolor}/>
            <p>NITHIN</p>
              <select id="lang" onChange={this.change} valueone={this.state.value} valuetwo={this.state.value1}>
                   <option value="red">red</option>
                   <option value="red">red</option>
                   <option value="blue">blue</option>
                   <option value="yellow">yellow</option>
                   <option value="yellow">yellow</option>
              </select>
         </div>
      );
   }
}

export default App;
