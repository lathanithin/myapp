import React from 'react';

class ChildTwo extends React.Component {
   render() {
     console.log("child two updated");
      return (
         <div>
            <h2>Hi i am Second child</h2>
            <p style={{backgroundColor:this.props.valuetwo}}>{this.props.valuetwo}</p>
         </div>
      );
   }
}
export default ChildTwo;
